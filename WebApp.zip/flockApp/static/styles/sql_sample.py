import pymssql
conn = pymssql.connect(server='myflockvalpha1.cz4wbu14kdie.us-west-2.rds.amazonaws.com:1433', user='flockadmin', password='flockpassword', database='FlockDB')
